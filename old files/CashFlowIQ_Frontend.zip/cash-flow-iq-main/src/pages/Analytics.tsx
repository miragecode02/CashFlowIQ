import { motion } from "framer-motion";
import { TrendingDown, Sparkles, ShoppingBag, UtensilsCrossed, Car, Gamepad2 } from "lucide-react";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, ResponsiveContainer, Tooltip,
  PieChart, Pie, Cell,
} from "recharts";

const weeklyTrend = [
  { day: "Mon", amount: 1200 },
  { day: "Tue", amount: 800 },
  { day: "Wed", amount: 2400 },
  { day: "Thu", amount: 1600 },
  { day: "Fri", amount: 3200 },
  { day: "Sat", amount: 4100 },
  { day: "Sun", amount: 1900 },
];

const pieData = [
  { name: "Food", value: 12400, color: "hsl(0, 84%, 60%)" },
  { name: "Shopping", value: 8600, color: "hsl(217, 91%, 60%)" },
  { name: "Transport", value: 5200, color: "hsl(160, 84%, 39%)" },
  { name: "Entertainment", value: 3800, color: "hsl(38, 92%, 50%)" },
];

const categories = [
  { name: "Food & Dining", icon: UtensilsCrossed, amount: 12400, pct: 32, color: "bg-destructive" },
  { name: "Shopping", icon: ShoppingBag, amount: 8600, pct: 22, color: "bg-primary" },
  { name: "Transport", icon: Car, amount: 5200, pct: 14, color: "bg-accent" },
  { name: "Entertainment", icon: Gamepad2, amount: 3800, pct: 10, color: "bg-chart-amber" },
];

const container = {
  hidden: { opacity: 0 },
  show: { opacity: 1, transition: { staggerChildren: 0.08 } },
};
const item = {
  hidden: { opacity: 0, y: 16 },
  show: { opacity: 1, y: 0, transition: { duration: 0.4 } },
};

const Analytics = () => {
  return (
    <motion.div
      className="space-y-4 pb-24 px-4 pt-6 max-w-md mx-auto"
      variants={container}
      initial="hidden"
      animate="show"
    >
      <motion.h1 variants={item} className="text-xl font-bold text-foreground">
        Spending Analytics
      </motion.h1>

      <Tabs defaultValue="weekly">
        <motion.div variants={item}>
          <TabsList className="w-full bg-secondary">
            <TabsTrigger value="weekly" className="flex-1">Weekly</TabsTrigger>
            <TabsTrigger value="monthly" className="flex-1">Monthly</TabsTrigger>
          </TabsList>
        </motion.div>

        <TabsContent value="weekly" className="space-y-4 mt-4">
          {/* AI Insight */}
          <motion.div variants={item} className="glass-card p-3 border-l-2 border-l-primary flex items-start gap-2">
            <Sparkles className="h-4 w-4 text-primary mt-0.5 shrink-0" />
            <p className="text-xs text-muted-foreground">
              Weekend spending is <span className="text-destructive font-medium">2.3x higher</span> than weekdays. Set a weekend budget to save more.
            </p>
          </motion.div>

          {/* Total */}
          <motion.div variants={item} className="glass-card p-4">
            <p className="text-xs text-muted-foreground">Total Spent This Week</p>
            <div className="flex items-baseline gap-2 mt-1">
              <p className="text-2xl font-bold text-foreground">₹15,200</p>
              <span className="flex items-center text-xs font-medium text-destructive">
                <TrendingDown className="h-3 w-3 mr-0.5" /> +8% vs last week
              </span>
            </div>
          </motion.div>

          {/* Trend Chart */}
          <motion.div variants={item} className="glass-card p-4">
            <p className="text-sm font-semibold text-foreground mb-3">Spending Trend</p>
            <div className="h-44">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={weeklyTrend}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(225, 20%, 18%)" />
                  <XAxis dataKey="day" tick={{ fill: "hsl(215, 20%, 55%)", fontSize: 11 }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fill: "hsl(215, 20%, 55%)", fontSize: 11 }} axisLine={false} tickLine={false} tickFormatter={(v) => `${v / 1000}k`} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "hsl(225, 40%, 11%)",
                      border: "1px solid hsl(225, 20%, 18%)",
                      borderRadius: "8px",
                      color: "hsl(210, 40%, 96%)",
                      fontSize: 12,
                    }}
                  />
                  <Line type="monotone" dataKey="amount" stroke="hsl(217, 91%, 60%)" strokeWidth={2.5} dot={{ r: 4, fill: "hsl(217, 91%, 60%)" }} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </motion.div>

          {/* Distribution Donut */}
          <motion.div variants={item} className="glass-card p-4">
            <p className="text-sm font-semibold text-foreground mb-3">Expense Distribution</p>
            <div className="flex items-center gap-4">
              <div className="h-36 w-36 shrink-0">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie data={pieData} cx="50%" cy="50%" innerRadius={36} outerRadius={60} dataKey="value" strokeWidth={0}>
                      {pieData.map((entry, i) => (
                        <Cell key={i} fill={entry.color} />
                      ))}
                    </Pie>
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="space-y-2 flex-1">
                {pieData.map((d) => (
                  <div key={d.name} className="flex items-center gap-2">
                    <div className="h-2.5 w-2.5 rounded-sm shrink-0" style={{ backgroundColor: d.color }} />
                    <span className="text-xs text-muted-foreground flex-1">{d.name}</span>
                    <span className="text-xs font-medium text-foreground">₹{d.value.toLocaleString("en-IN")}</span>
                  </div>
                ))}
              </div>
            </div>
          </motion.div>

          {/* Top Categories */}
          <motion.div variants={item} className="glass-card p-4">
            <p className="text-sm font-semibold text-foreground mb-3">Top Categories</p>
            <div className="space-y-3">
              {categories.map((cat) => (
                <div key={cat.name} className="flex items-center gap-3">
                  <div className={`h-9 w-9 rounded-xl ${cat.color}/20 flex items-center justify-center`}>
                    <cat.icon className="h-4 w-4 text-foreground" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex justify-between items-center mb-1">
                      <p className="text-xs font-medium text-foreground">{cat.name}</p>
                      <p className="text-xs font-semibold text-foreground">₹{cat.amount.toLocaleString("en-IN")}</p>
                    </div>
                    <Progress value={cat.pct} className="h-1.5 bg-secondary" />
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        </TabsContent>

        <TabsContent value="monthly" className="mt-4">
          <div className="glass-card p-6 text-center">
            <p className="text-sm text-muted-foreground">Monthly view coming soon</p>
          </div>
        </TabsContent>
      </Tabs>
    </motion.div>
  );
};

export default Analytics;
