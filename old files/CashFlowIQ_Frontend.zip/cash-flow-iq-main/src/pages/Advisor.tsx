import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Send, Sparkles, Bot, User } from "lucide-react";
import { Input } from "@/components/ui/input";
import {
  BarChart, Bar, XAxis, ResponsiveContainer,
} from "recharts";

interface Message {
  id: number;
  role: "user" | "assistant";
  content: string;
  chart?: { month: string; amount: number }[];
}

const suggestedPrompts = [
  "Can I afford a ₹80k phone?",
  "Why am I not saving money?",
  "Suggest a better monthly budget",
];

const initialMessages: Message[] = [
  {
    id: 1,
    role: "assistant",
    content:
      "Hey Arjun! 👋 I'm your AI Financial Advisor. You spent ₹43,000 this month — 72% of budget. Your savings rate is strong at 75%. How can I help?",
  },
];

const cashFlowProjection = [
  { month: "Apr", amount: 35000 },
  { month: "May", amount: 32000 },
  { month: "Jun", amount: 28000 },
  { month: "Jul", amount: 25000 },
  { month: "Aug", amount: 22000 },
];

const Advisor = () => {
  const [messages, setMessages] = useState<Message[]>(initialMessages);
  const [input, setInput] = useState("");

  const handleSend = (text?: string) => {
    const msg = text || input;
    if (!msg.trim()) return;

    const userMsg: Message = { id: Date.now(), role: "user", content: msg };
    setMessages((prev) => [...prev, userMsg]);
    setInput("");

    // Simulated AI response
    setTimeout(() => {
      const aiMsg: Message = {
        id: Date.now() + 1,
        role: "assistant",
        content:
          msg.includes("80k") || msg.includes("phone")
            ? "Based on your current savings rate, you can afford the ₹80k phone in 8 months using the IQ Strategy. Here's your projected cash flow if you save ₹10,000/month:"
            : msg.includes("saving")
            ? "Your top spending leaks are food delivery (₹12,400) and impulse shopping (₹8,600). Reducing these by 30% would boost your savings by ₹6,300/month."
            : "Great question! Based on your income of ₹78,000 and expenses, I recommend the 50/30/20 rule: ₹39,000 needs, ₹23,400 wants, ₹15,600 savings.",
        chart:
          msg.includes("80k") || msg.includes("phone") ? cashFlowProjection : undefined,
      };
      setMessages((prev) => [...prev, aiMsg]);
    }, 800);
  };

  return (
    <div className="flex flex-col h-[calc(100dvh-72px)] max-w-md mx-auto">
      {/* Header */}
      <div className="px-4 pt-6 pb-3">
        <h1 className="text-xl font-bold text-foreground">AI Advisor</h1>
        <p className="text-xs text-muted-foreground">Powered by Cash Flow IQ</p>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto px-4 space-y-3 pb-4">
        <AnimatePresence>
          {messages.map((msg) => (
            <motion.div
              key={msg.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className={`flex gap-2 ${msg.role === "user" ? "justify-end" : "justify-start"}`}
            >
              {msg.role === "assistant" && (
                <div className="h-7 w-7 rounded-full gradient-accent flex items-center justify-center shrink-0 mt-1">
                  <Bot className="h-3.5 w-3.5 text-primary-foreground" />
                </div>
              )}
              <div className="max-w-[80%] space-y-2">
                <div
                  className={`px-3.5 py-2.5 rounded-2xl text-xs leading-relaxed ${
                    msg.role === "user"
                      ? "gradient-accent text-primary-foreground rounded-br-md"
                      : "glass-card text-foreground rounded-bl-md"
                  }`}
                >
                  {msg.content}
                </div>
                {msg.chart && (
                  <div className="glass-card p-3 rounded-xl">
                    <p className="text-[10px] text-muted-foreground mb-1.5">Projected Cash Flow</p>
                    <div className="h-24">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={msg.chart}>
                          <XAxis dataKey="month" tick={{ fill: "hsl(215, 20%, 55%)", fontSize: 9 }} axisLine={false} tickLine={false} />
                          <Bar dataKey="amount" fill="hsl(160, 84%, 39%)" radius={[4, 4, 0, 0]} />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </div>
                )}
              </div>
              {msg.role === "user" && (
                <div className="h-7 w-7 rounded-full bg-secondary flex items-center justify-center shrink-0 mt-1">
                  <User className="h-3.5 w-3.5 text-muted-foreground" />
                </div>
              )}
            </motion.div>
          ))}
        </AnimatePresence>

        {/* Suggested prompts */}
        {messages.length <= 1 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3 }}
            className="flex flex-wrap gap-2 mt-2"
          >
            {suggestedPrompts.map((p) => (
              <button
                key={p}
                onClick={() => handleSend(p)}
                className="text-[11px] px-3 py-1.5 rounded-full border border-primary/30 text-primary hover:bg-primary/10 transition-colors"
              >
                {p}
              </button>
            ))}
          </motion.div>
        )}
      </div>

      {/* Input */}
      <div className="px-4 pb-4 pt-2 border-t border-border/40">
        <div className="flex gap-2">
          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleSend()}
            placeholder="Ask about your finances..."
            className="bg-secondary border-border/50 text-foreground text-xs"
          />
          <button
            onClick={() => handleSend()}
            className="h-10 w-10 rounded-xl gradient-accent flex items-center justify-center shrink-0 hover:opacity-90 transition-opacity"
          >
            <Send className="h-4 w-4 text-primary-foreground" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default Advisor;
