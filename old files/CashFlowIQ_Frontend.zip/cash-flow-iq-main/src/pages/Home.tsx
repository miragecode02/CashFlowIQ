import { TrendingUp, Plus, ArrowUpRight, Sparkles, IndianRupee } from "lucide-react";
import { motion } from "framer-motion";
import { Progress } from "@/components/ui/progress";
import CircularGauge from "@/components/CircularGauge";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, ResponsiveContainer, Tooltip,
} from "recharts";

const incomeVsSpending = [
  { month: "Oct", income: 65000, spending: 42000 },
  { month: "Nov", income: 68000, spending: 45000 },
  { month: "Dec", income: 72000, spending: 55000 },
  { month: "Jan", income: 70000, spending: 48000 },
  { month: "Feb", income: 75000, spending: 46000 },
  { month: "Mar", income: 78000, spending: 43000 },
];

const container = {
  hidden: { opacity: 0 },
  show: { opacity: 1, transition: { staggerChildren: 0.08 } },
};
const item = {
  hidden: { opacity: 0, y: 16 },
  show: { opacity: 1, y: 0, transition: { duration: 0.4 } },
};

const Home = () => {
  return (
    <motion.div
      className="space-y-4 pb-24 px-4 pt-6 max-w-md mx-auto"
      variants={container}
      initial="hidden"
      animate="show"
    >
      {/* Header */}
      <motion.div variants={item} className="flex items-center justify-between">
        <div>
          <p className="text-sm text-muted-foreground">Good morning,</p>
          <h1 className="text-xl font-bold text-foreground">Arjun 👋</h1>
        </div>
        <div className="h-9 w-9 rounded-full gradient-accent flex items-center justify-center text-sm font-bold text-primary-foreground">
          A
        </div>
      </motion.div>

      {/* Net Worth Card */}
      <motion.div variants={item} className="gradient-card p-5">
        <p className="text-xs text-muted-foreground mb-1">Total Net Worth</p>
        <div className="flex items-baseline gap-2">
          <h2 className="text-3xl font-bold text-foreground flex items-center">
            <IndianRupee className="h-6 w-6" />4,52,000
          </h2>
          <span className="flex items-center text-xs font-medium text-mint">
            <ArrowUpRight className="h-3 w-3" /> 12.4%
          </span>
        </div>
        <p className="text-xs text-muted-foreground mt-1">vs last month</p>
      </motion.div>

      {/* Add Expense Button */}
      <motion.button
        variants={item}
        className="w-full gradient-accent text-primary-foreground font-semibold py-3 rounded-xl flex items-center justify-center gap-2 hover:opacity-90 transition-opacity"
      >
        <Plus className="h-4 w-4" /> Add Expense
      </motion.button>

      {/* Monthly Budget */}
      <motion.div variants={item} className="glass-card p-4">
        <div className="flex justify-between items-center mb-2">
          <p className="text-sm font-medium text-foreground">Monthly Budget</p>
          <p className="text-xs text-muted-foreground">₹43,000 / ₹60,000</p>
        </div>
        <Progress value={72} className="h-2 bg-secondary" />
        <p className="text-xs text-muted-foreground mt-1.5">₹17,000 remaining · 8 days left</p>
      </motion.div>

      {/* AI Insight Card */}
      <motion.div variants={item} className="glass-card p-4 border-l-2 border-l-primary">
        <div className="flex items-center gap-2 mb-2">
          <Sparkles className="h-4 w-4 text-primary" />
          <p className="text-sm font-semibold text-foreground">AI Smart Insight</p>
        </div>
        <p className="text-xs text-muted-foreground leading-relaxed">
          Your food delivery spending is up <span className="text-destructive font-medium">23%</span> this week.
          Consider cooking at home 2 more days to save <span className="text-mint font-medium">₹1,800/month</span>.
        </p>
      </motion.div>

      {/* Savings Rate & Top Category */}
      <motion.div variants={item} className="grid grid-cols-2 gap-3">
        <div className="glass-card p-4 flex flex-col items-center">
          <CircularGauge value={75} size={100} strokeWidth={7} color="hsl(160, 84%, 39%)" />
          <p className="text-xs font-medium text-foreground mt-2">Savings Rate</p>
        </div>
        <div className="glass-card p-4 flex flex-col justify-between">
          <p className="text-xs text-muted-foreground">Top Category</p>
          <p className="text-lg font-bold text-foreground mt-1">Food</p>
          <p className="text-2xl font-bold text-destructive">₹12,400</p>
          <p className="text-xs text-muted-foreground">32% of spending</p>
        </div>
      </motion.div>

      {/* Income vs Spending Chart */}
      <motion.div variants={item} className="glass-card p-4">
        <div className="flex items-center gap-2 mb-3">
          <TrendingUp className="h-4 w-4 text-primary" />
          <p className="text-sm font-semibold text-foreground">Income vs Spending</p>
        </div>
        <div className="h-48">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={incomeVsSpending} barGap={4}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(225, 20%, 18%)" />
              <XAxis dataKey="month" tick={{ fill: "hsl(215, 20%, 55%)", fontSize: 11 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: "hsl(215, 20%, 55%)", fontSize: 11 }} axisLine={false} tickLine={false} tickFormatter={(v) => `${v / 1000}k`} />
              <Tooltip
                contentStyle={{
                  backgroundColor: "hsl(225, 40%, 11%)",
                  border: "1px solid hsl(225, 20%, 18%)",
                  borderRadius: "8px",
                  color: "hsl(210, 40%, 96%)",
                  fontSize: 12,
                }}
              />
              <Bar dataKey="income" fill="hsl(217, 91%, 60%)" radius={[4, 4, 0, 0]} />
              <Bar dataKey="spending" fill="hsl(245, 58%, 51%)" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
        <div className="flex items-center gap-4 mt-2 justify-center">
          <div className="flex items-center gap-1.5">
            <div className="h-2.5 w-2.5 rounded-sm bg-primary" />
            <span className="text-xs text-muted-foreground">Income</span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="h-2.5 w-2.5 rounded-sm bg-chart-indigo" />
            <span className="text-xs text-muted-foreground">Spending</span>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
};

export default Home;
