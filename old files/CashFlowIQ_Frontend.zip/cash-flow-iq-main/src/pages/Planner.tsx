import { useState } from "react";
import { motion } from "framer-motion";
import { Sparkles, PiggyBank, Scissors, Star, Check } from "lucide-react";
import { Input } from "@/components/ui/input";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, ResponsiveContainer, Tooltip,
} from "recharts";

const impactData = [
  { quarter: "Q1", savings: 45000 },
  { quarter: "Q2", savings: 92000 },
  { quarter: "Q3", savings: 145000 },
  { quarter: "Q4", savings: 210000 },
];

const strategies = [
  {
    id: "saver",
    title: "Disciplined Saver",
    icon: PiggyBank,
    description: "Save ₹8,000/month for 10 months",
    detail: "No lifestyle changes needed. Steady saving from income.",
    highlighted: false,
  },
  {
    id: "trim",
    title: "Lifestyle Trim",
    icon: Scissors,
    description: "Cut food delivery by 40% + save ₹12,000/mo",
    detail: "Reach your goal in 7 months by reducing dining out.",
    highlighted: false,
  },
  {
    id: "iq",
    title: "IQ Recommendation",
    icon: Star,
    description: "Smart mix: Save ₹10,000/mo + cashback rewards",
    detail: "Optimized strategy using cashback cards & auto-invest. Goal in 8 months.",
    highlighted: true,
  },
];

const container = {
  hidden: { opacity: 0 },
  show: { opacity: 1, transition: { staggerChildren: 0.08 } },
};
const item = {
  hidden: { opacity: 0, y: 16 },
  show: { opacity: 1, y: 0, transition: { duration: 0.4 } },
};

const Planner = () => {
  const [selectedStrategy, setSelectedStrategy] = useState("iq");
  const [itemName, setItemName] = useState("iPhone 16 Pro");
  const [itemPrice, setItemPrice] = useState("79999");

  return (
    <motion.div
      className="space-y-4 pb-24 px-4 pt-6 max-w-md mx-auto"
      variants={container}
      initial="hidden"
      animate="show"
    >
      <motion.h1 variants={item} className="text-xl font-bold text-foreground">
        Purchase Planner
      </motion.h1>

      <motion.p variants={item} className="text-xs text-muted-foreground">
        Plan your next big purchase with AI-powered strategies.
      </motion.p>

      {/* Inputs */}
      <motion.div variants={item} className="glass-card p-4 space-y-3">
        <div>
          <label className="text-xs text-muted-foreground mb-1 block">Item Name</label>
          <Input
            value={itemName}
            onChange={(e) => setItemName(e.target.value)}
            className="bg-secondary border-border/50 text-foreground"
            placeholder="e.g. iPhone 16 Pro"
          />
        </div>
        <div>
          <label className="text-xs text-muted-foreground mb-1 block">Price (₹)</label>
          <Input
            value={itemPrice}
            onChange={(e) => setItemPrice(e.target.value)}
            className="bg-secondary border-border/50 text-foreground"
            placeholder="e.g. 79999"
            type="number"
          />
        </div>
      </motion.div>

      {/* AI Strategies */}
      <motion.div variants={item}>
        <div className="flex items-center gap-2 mb-3">
          <Sparkles className="h-4 w-4 text-primary" />
          <p className="text-sm font-semibold text-foreground">AI Strategies</p>
        </div>
        <div className="space-y-3">
          {strategies.map((s) => {
            const isSelected = selectedStrategy === s.id;
            return (
              <motion.button
                key={s.id}
                onClick={() => setSelectedStrategy(s.id)}
                className={`w-full text-left p-4 rounded-2xl border transition-all ${
                  s.highlighted && isSelected
                    ? "gradient-card border-primary/50 ring-1 ring-primary/30"
                    : isSelected
                    ? "glass-card border-primary/40"
                    : "glass-card border-border/30 opacity-80"
                }`}
                whileTap={{ scale: 0.98 }}
              >
                <div className="flex items-start gap-3">
                  <div className={`h-9 w-9 rounded-xl flex items-center justify-center shrink-0 ${
                    s.highlighted ? "gradient-accent" : "bg-secondary"
                  }`}>
                    <s.icon className="h-4 w-4 text-primary-foreground" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <p className="text-sm font-semibold text-foreground">{s.title}</p>
                      {s.highlighted && (
                        <span className="text-[10px] font-semibold text-primary bg-primary/10 px-1.5 py-0.5 rounded-full">
                          BEST
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-mint font-medium mt-0.5">{s.description}</p>
                    <p className="text-xs text-muted-foreground mt-1">{s.detail}</p>
                  </div>
                  {isSelected && (
                    <div className="h-5 w-5 rounded-full gradient-accent flex items-center justify-center shrink-0">
                      <Check className="h-3 w-3 text-primary-foreground" />
                    </div>
                  )}
                </div>
              </motion.button>
            );
          })}
        </div>
      </motion.div>

      {/* Savings Impact Chart */}
      <motion.div variants={item} className="glass-card p-4">
        <p className="text-sm font-semibold text-foreground mb-3">Savings Impact Projection</p>
        <div className="h-44">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={impactData}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(225, 20%, 18%)" />
              <XAxis dataKey="quarter" tick={{ fill: "hsl(215, 20%, 55%)", fontSize: 11 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: "hsl(215, 20%, 55%)", fontSize: 11 }} axisLine={false} tickLine={false} tickFormatter={(v) => `${v / 1000}k`} />
              <Tooltip
                contentStyle={{
                  backgroundColor: "hsl(225, 40%, 11%)",
                  border: "1px solid hsl(225, 20%, 18%)",
                  borderRadius: "8px",
                  color: "hsl(210, 40%, 96%)",
                  fontSize: 12,
                }}
              />
              <Bar dataKey="savings" fill="hsl(160, 84%, 39%)" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </motion.div>

      {/* CTA */}
      <motion.button
        variants={item}
        className="w-full gradient-accent text-primary-foreground font-semibold py-3 rounded-xl hover:opacity-90 transition-opacity"
      >
        Select Strategy & Start Saving
      </motion.button>
    </motion.div>
  );
};

export default Planner;
