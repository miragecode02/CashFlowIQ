import { motion } from "framer-motion";
import { Settings, Bell, CreditCard, HelpCircle, LogOut, ChevronRight } from "lucide-react";

const menuItems = [
  { icon: CreditCard, label: "Linked Accounts", subtitle: "3 accounts connected" },
  { icon: Bell, label: "Notifications", subtitle: "Push & email alerts" },
  { icon: Settings, label: "Settings", subtitle: "Currency, language, theme" },
  { icon: HelpCircle, label: "Help & Support", subtitle: "FAQs and contact" },
];

const container = {
  hidden: { opacity: 0 },
  show: { opacity: 1, transition: { staggerChildren: 0.08 } },
};
const item = {
  hidden: { opacity: 0, y: 16 },
  show: { opacity: 1, y: 0, transition: { duration: 0.4 } },
};

const Profile = () => {
  return (
    <motion.div
      className="space-y-4 pb-24 px-4 pt-6 max-w-md mx-auto"
      variants={container}
      initial="hidden"
      animate="show"
    >
      <motion.h1 variants={item} className="text-xl font-bold text-foreground">
        Profile
      </motion.h1>

      {/* User Card */}
      <motion.div variants={item} className="gradient-card p-5 flex items-center gap-4">
        <div className="h-14 w-14 rounded-full gradient-accent flex items-center justify-center text-xl font-bold text-primary-foreground">
          A
        </div>
        <div>
          <p className="text-base font-semibold text-foreground">Arjun Mehta</p>
          <p className="text-xs text-muted-foreground">arjun@email.com</p>
          <span className="text-[10px] font-semibold text-primary bg-primary/10 px-2 py-0.5 rounded-full mt-1 inline-block">
            PRO Member
          </span>
        </div>
      </motion.div>

      {/* Stats */}
      <motion.div variants={item} className="grid grid-cols-3 gap-3">
        <div className="glass-card p-3 text-center">
          <p className="text-lg font-bold text-foreground">156</p>
          <p className="text-[10px] text-muted-foreground">Transactions</p>
        </div>
        <div className="glass-card p-3 text-center">
          <p className="text-lg font-bold text-mint">78</p>
          <p className="text-[10px] text-muted-foreground">Health Score</p>
        </div>
        <div className="glass-card p-3 text-center">
          <p className="text-lg font-bold text-primary">12</p>
          <p className="text-[10px] text-muted-foreground">Months Active</p>
        </div>
      </motion.div>

      {/* Menu */}
      <motion.div variants={item} className="glass-card divide-y divide-border/30">
        {menuItems.map((m) => (
          <button key={m.label} className="w-full flex items-center gap-3 p-4 hover:bg-secondary/50 transition-colors">
            <m.icon className="h-5 w-5 text-muted-foreground" />
            <div className="flex-1 text-left">
              <p className="text-sm font-medium text-foreground">{m.label}</p>
              <p className="text-[10px] text-muted-foreground">{m.subtitle}</p>
            </div>
            <ChevronRight className="h-4 w-4 text-muted-foreground" />
          </button>
        ))}
      </motion.div>

      <motion.button
        variants={item}
        className="w-full flex items-center justify-center gap-2 py-3 rounded-xl border border-destructive/30 text-destructive text-sm font-medium hover:bg-destructive/10 transition-colors"
      >
        <LogOut className="h-4 w-4" /> Log Out
      </motion.button>
    </motion.div>
  );
};

export default Profile;
