import { motion } from "framer-motion";
import { Shield, TrendingUp, AlertTriangle, Sparkles, ArrowUpRight } from "lucide-react";
import { Progress } from "@/components/ui/progress";
import CircularGauge from "@/components/CircularGauge";

const container = {
  hidden: { opacity: 0 },
  show: { opacity: 1, transition: { staggerChildren: 0.08 } },
};
const item = {
  hidden: { opacity: 0, y: 16 },
  show: { opacity: 1, y: 0, transition: { duration: 0.4 } },
};

const FinancialHealth = () => {
  return (
    <motion.div
      className="space-y-4 pb-24 px-4 pt-6 max-w-md mx-auto"
      variants={container}
      initial="hidden"
      animate="show"
    >
      <motion.h1 variants={item} className="text-xl font-bold text-foreground">
        Financial Health
      </motion.h1>

      {/* Score Gauge */}
      <motion.div variants={item} className="gradient-card p-6 flex flex-col items-center">
        <CircularGauge
          value={78}
          size={160}
          strokeWidth={10}
          color="hsl(160, 84%, 39%)"
        />
        <p className="text-lg font-bold text-foreground mt-3">Good</p>
        <p className="text-xs text-muted-foreground">Your financial health is above average</p>
      </motion.div>

      {/* Savings Rate */}
      <motion.div variants={item} className="glass-card p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <TrendingUp className="h-4 w-4 text-mint" />
            <p className="text-sm font-medium text-foreground">Savings Rate</p>
          </div>
          <span className="flex items-center text-xs font-medium text-mint">
            <ArrowUpRight className="h-3 w-3" /> +5% MoM
          </span>
        </div>
        <p className="text-3xl font-bold text-foreground mt-2">75%</p>
        <p className="text-xs text-muted-foreground">You save ₹58,500 of ₹78,000 income</p>
      </motion.div>

      {/* Emergency Fund */}
      <motion.div variants={item} className="glass-card p-4">
        <div className="flex items-center gap-2 mb-2">
          <Shield className="h-4 w-4 text-primary" />
          <p className="text-sm font-medium text-foreground">Emergency Fund</p>
        </div>
        <div className="flex justify-between items-center mb-1.5">
          <p className="text-xs text-muted-foreground">₹1,80,000 / ₹3,00,000</p>
          <p className="text-xs font-medium text-foreground">60%</p>
        </div>
        <Progress value={60} className="h-2 bg-secondary" />
        <p className="text-xs text-muted-foreground mt-1.5">4 months of expenses covered (goal: 6 months)</p>
      </motion.div>

      {/* Risk & Diversification */}
      <motion.div variants={item} className="grid grid-cols-2 gap-3">
        <div className="glass-card p-4">
          <div className="flex items-center gap-1.5 mb-2">
            <AlertTriangle className="h-3.5 w-3.5 text-chart-amber" />
            <p className="text-xs text-muted-foreground">Risk Level</p>
          </div>
          <p className="text-lg font-bold text-chart-amber">Medium</p>
          <p className="text-[10px] text-muted-foreground mt-0.5">Moderate exposure</p>
        </div>
        <div className="glass-card p-4">
          <div className="flex items-center gap-1.5 mb-2">
            <Shield className="h-3.5 w-3.5 text-mint" />
            <p className="text-xs text-muted-foreground">Diversification</p>
          </div>
          <p className="text-lg font-bold text-mint">Good</p>
          <p className="text-[10px] text-muted-foreground mt-0.5">4 asset classes</p>
        </div>
      </motion.div>

      {/* Smart Insights */}
      <motion.div variants={item} className="glass-card p-4 border-l-2 border-l-primary">
        <div className="flex items-center gap-2 mb-2">
          <Sparkles className="h-4 w-4 text-primary" />
          <p className="text-sm font-semibold text-foreground">Smart Insights</p>
        </div>
        <ul className="space-y-2">
          <li className="text-xs text-muted-foreground flex items-start gap-2">
            <span className="h-1.5 w-1.5 rounded-full bg-mint mt-1 shrink-0" />
            Increase SIP by ₹2,000 to reach emergency fund goal 2 months earlier.
          </li>
          <li className="text-xs text-muted-foreground flex items-start gap-2">
            <span className="h-1.5 w-1.5 rounded-full bg-primary mt-1 shrink-0" />
            Consider term insurance — you have dependents but no coverage.
          </li>
          <li className="text-xs text-muted-foreground flex items-start gap-2">
            <span className="h-1.5 w-1.5 rounded-full bg-chart-amber mt-1 shrink-0" />
            Your credit utilization is 45% — aim for below 30% to improve score.
          </li>
        </ul>
      </motion.div>
    </motion.div>
  );
};

export default FinancialHealth;
