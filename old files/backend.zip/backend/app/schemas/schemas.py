from pydantic import BaseModel, EmailStr, field_validator
from typing import Optional, List
from datetime import datetime
from app.models.models import TransactionType


# ── Auth ──────────────────────────────────────────────────────────────────────
class UserRegister(BaseModel):
    name: str
    email: EmailStr
    password: str

    @field_validator("password")
    @classmethod
    def password_strength(cls, v):
        if len(v) < 8:
            raise ValueError("Password must be at least 8 characters")
        return v


class UserLogin(BaseModel):
    email: EmailStr
    password: str


class UserOut(BaseModel):
    id: int
    name: str
    email: str
    is_active: bool
    created_at: datetime

    model_config = {"from_attributes": True}


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserOut


# ── Categories ────────────────────────────────────────────────────────────────
class CategoryOut(BaseModel):
    id: int
    name: str
    icon: Optional[str]
    color: Optional[str]

    model_config = {"from_attributes": True}


# ── Transactions ──────────────────────────────────────────────────────────────
class TransactionCreate(BaseModel):
    amount: float
    type: TransactionType
    description: str
    note: Optional[str] = None
    category_id: Optional[int] = None
    date: datetime

    @field_validator("amount")
    @classmethod
    def amount_positive(cls, v):
        if v <= 0:
            raise ValueError("Amount must be positive")
        return v


class TransactionOut(BaseModel):
    id: int
    amount: float
    type: TransactionType
    description: str
    note: Optional[str]
    date: datetime
    created_at: datetime
    category: Optional[CategoryOut]

    model_config = {"from_attributes": True}


class TransactionUpdate(BaseModel):
    amount: Optional[float] = None
    description: Optional[str] = None
    note: Optional[str] = None
    category_id: Optional[int] = None
    date: Optional[datetime] = None


# ── Budgets ───────────────────────────────────────────────────────────────────
class BudgetCreate(BaseModel):
    amount: float
    category_id: Optional[int] = None
    month: int
    year: int


class BudgetOut(BaseModel):
    id: int
    amount: float
    month: int
    year: int
    category: Optional[CategoryOut]
    spent: Optional[float] = 0.0
    remaining: Optional[float] = None

    model_config = {"from_attributes": True}


# ── Analytics ─────────────────────────────────────────────────────────────────
class MonthlyTrend(BaseModel):
    month: str
    income: float
    spending: float


class CategoryBreakdown(BaseModel):
    name: str
    amount: float
    percentage: float
    color: Optional[str]


class AnalyticsSummary(BaseModel):
    total_income: float
    total_spending: float
    net_savings: float
    savings_rate: float
    monthly_trends: List[MonthlyTrend]
    category_breakdown: List[CategoryBreakdown]
    top_category: Optional[CategoryBreakdown]


class ForecastPoint(BaseModel):
    date: str
    predicted_spending: float
    lower_bound: float
    upper_bound: float


# ── Chat ──────────────────────────────────────────────────────────────────────
class ChatRequest(BaseModel):
    message: str


class ChatMessageOut(BaseModel):
    id: int
    role: str
    content: str
    created_at: datetime

    model_config = {"from_attributes": True}


class ChatResponse(BaseModel):
    reply: str
    history: List[ChatMessageOut]
