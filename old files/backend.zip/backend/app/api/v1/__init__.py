from fastapi import APIRouter
from app.api.v1.endpoints import auth, transactions, analytics, chat, budgets

router = APIRouter()
router.include_router(auth.router)
router.include_router(transactions.router)
router.include_router(analytics.router)
router.include_router(chat.router)
router.include_router(budgets.router)
