import google.generativeai as genai
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.core.config import settings
from app.models.models import ChatMessage, Transaction, TransactionType, Budget
from app.services.analytics_service import get_analytics_summary
from datetime import datetime

genai.configure(api_key=settings.GEMINI_API_KEY)


def _build_system_prompt(user_name: str, summary) -> str:
    return f"""You are Cash Flow IQ, an expert AI financial advisor for Indian users.

USER CONTEXT:
- Name: {user_name}
- This month's income: ₹{summary.total_income:,.0f}
- This month's spending: ₹{summary.total_spending:,.0f}
- Net savings: ₹{summary.net_savings:,.0f}
- Savings rate: {summary.savings_rate:.1f}%
- Top spending category: {summary.top_category.name if summary.top_category else "N/A"} (₹{summary.top_category.amount:,.0f} = {summary.top_category.percentage:.0f}% of spending)

GUIDELINES:
- Be concise, warm, and actionable — like a knowledgeable friend
- Always use Indian Rupee (₹) formatting
- Reference the user's ACTUAL financial data when relevant
- For purchase simulations, calculate months to save, impact on savings rate
- For budget advice, use the 50/30/20 or custom rule
- Keep responses under 150 words unless complex analysis is requested
- Use emojis sparingly for friendliness

Today's date: {datetime.now().strftime("%d %B %Y")}"""


async def get_chat_history(db: AsyncSession, user_id: int, limit: int = 10) -> list[ChatMessage]:
    result = await db.execute(
        select(ChatMessage)
        .where(ChatMessage.user_id == user_id)
        .order_by(ChatMessage.created_at.desc())
        .limit(limit)
    )
    messages = result.scalars().all()
    return list(reversed(messages))


async def chat_with_advisor(
    db: AsyncSession, user_id: int, user_name: str, message: str
) -> str:
    # Get financial context
    summary = await get_analytics_summary(db, user_id)

    # Get conversation history
    history = await get_chat_history(db, user_id)

    # Build Gemini conversation
    model = genai.GenerativeModel(
        model_name="gemini-1.5-flash",
        system_instruction=_build_system_prompt(user_name, summary),
    )

    gemini_history = [
        {"role": "user" if msg.role == "user" else "model", "parts": [msg.content]}
        for msg in history
    ]

    chat = model.start_chat(history=gemini_history)
    response = chat.send_message(message)
    reply = response.text

    # Persist both messages
    user_msg = ChatMessage(user_id=user_id, role="user", content=message)
    ai_msg = ChatMessage(user_id=user_id, role="assistant", content=reply)
    db.add(user_msg)
    db.add(ai_msg)
    await db.flush()

    return reply
