from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from sqlalchemy.orm import selectinload
from app.models.models import Transaction, TransactionType, Category
from app.schemas.schemas import (
    AnalyticsSummary, MonthlyTrend, CategoryBreakdown, ForecastPoint
)
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from collections import defaultdict


async def get_analytics_summary(
    db: AsyncSession, user_id: int, months: int = 6
) -> AnalyticsSummary:
    result = await db.execute(
        select(Transaction)
        .options(selectinload(Transaction.category))
        .where(Transaction.user_id == user_id)
        .order_by(Transaction.date.desc())
    )
    transactions = result.scalars().all()

    if not transactions:
        return AnalyticsSummary(
            total_income=0, total_spending=0, net_savings=0,
            savings_rate=0, monthly_trends=[], category_breakdown=[], top_category=None
        )

    # Build DataFrame
    df = pd.DataFrame([{
        "date": t.date,
        "amount": t.amount,
        "type": t.type.value,
        "category": t.category.name if t.category else "Uncategorized",
        "category_color": t.category.color if t.category else "#6366f1",
    } for t in transactions])

    df["date"] = pd.to_datetime(df["date"])
    df["month_label"] = df["date"].dt.strftime("%b")
    df["month_year"] = df["date"].dt.to_period("M")

    # Monthly trends (last N months)
    recent = df[df["date"] >= datetime.now() - timedelta(days=30 * months)]
    monthly = (
        recent.groupby(["month_year", "type"])["amount"]
        .sum()
        .unstack(fill_value=0)
        .reset_index()
    )
    monthly["month_label"] = monthly["month_year"].dt.strftime("%b")

    monthly_trends = [
        MonthlyTrend(
            month=row["month_label"],
            income=float(row.get("income", 0)),
            spending=float(row.get("expense", 0)),
        )
        for _, row in monthly.iterrows()
    ]

    # Totals (current month)
    now = datetime.now()
    this_month = df[
        (df["date"].dt.month == now.month) & (df["date"].dt.year == now.year)
    ]
    total_income = float(this_month[this_month["type"] == "income"]["amount"].sum())
    total_spending = float(this_month[this_month["type"] == "expense"]["amount"].sum())
    net_savings = total_income - total_spending
    savings_rate = (net_savings / total_income * 100) if total_income > 0 else 0

    # Category breakdown (current month expenses)
    expenses = this_month[this_month["type"] == "expense"]
    cat_totals = expenses.groupby(["category", "category_color"])["amount"].sum().reset_index()
    cat_totals = cat_totals.sort_values("amount", ascending=False)

    breakdown = []
    for _, row in cat_totals.iterrows():
        pct = (row["amount"] / total_spending * 100) if total_spending > 0 else 0
        breakdown.append(CategoryBreakdown(
            name=row["category"],
            amount=float(row["amount"]),
            percentage=round(float(pct), 1),
            color=row["category_color"],
        ))

    top_category = breakdown[0] if breakdown else None

    return AnalyticsSummary(
        total_income=total_income,
        total_spending=total_spending,
        net_savings=net_savings,
        savings_rate=round(savings_rate, 1),
        monthly_trends=monthly_trends,
        category_breakdown=breakdown,
        top_category=top_category,
    )


async def get_spending_forecast(
    db: AsyncSession, user_id: int, days_ahead: int = 30
) -> list[ForecastPoint]:
    """Prophet-based cash flow forecast. Falls back to linear trend if insufficient data."""
    result = await db.execute(
        select(Transaction).where(
            Transaction.user_id == user_id,
            Transaction.type == TransactionType.expense,
        )
    )
    transactions = result.scalars().all()

    if len(transactions) < 14:
        # Not enough data — return simple linear estimate
        avg = np.mean([t.amount for t in transactions]) if transactions else 1000
        forecast = []
        for i in range(days_ahead):
            d = datetime.now() + timedelta(days=i + 1)
            forecast.append(ForecastPoint(
                date=d.strftime("%Y-%m-%d"),
                predicted_spending=round(avg, 2),
                lower_bound=round(avg * 0.8, 2),
                upper_bound=round(avg * 1.2, 2),
            ))
        return forecast

    try:
        from prophet import Prophet

        df = pd.DataFrame([{"ds": t.date, "y": t.amount} for t in transactions])
        df["ds"] = pd.to_datetime(df["ds"]).dt.tz_localize(None)
        daily = df.resample("D", on="ds")["y"].sum().reset_index()

        model = Prophet(yearly_seasonality=False, weekly_seasonality=True, daily_seasonality=False)
        model.fit(daily)

        future = model.make_future_dataframe(periods=days_ahead)
        forecast_df = model.predict(future)
        future_only = forecast_df[forecast_df["ds"] > datetime.now()].tail(days_ahead)

        return [
            ForecastPoint(
                date=row["ds"].strftime("%Y-%m-%d"),
                predicted_spending=max(0, round(row["yhat"], 2)),
                lower_bound=max(0, round(row["yhat_lower"], 2)),
                upper_bound=max(0, round(row["yhat_upper"], 2)),
            )
            for _, row in future_only.iterrows()
        ]
    except Exception:
        # Prophet not available — linear fallback
        daily_avg = sum(t.amount for t in transactions) / max(
            (transactions[0].date - transactions[-1].date).days, 1
        )
        return [
            ForecastPoint(
                date=(datetime.now() + timedelta(days=i + 1)).strftime("%Y-%m-%d"),
                predicted_spending=round(daily_avg, 2),
                lower_bound=round(daily_avg * 0.8, 2),
                upper_bound=round(daily_avg * 1.2, 2),
            )
            for i in range(days_ahead)
        ]


async def detect_anomalies(db: AsyncSession, user_id: int) -> list[dict]:
    """Flag transactions > 2 std deviations above category mean."""
    result = await db.execute(
        select(Transaction)
        .options(selectinload(Transaction.category))
        .where(
            Transaction.user_id == user_id,
            Transaction.type == TransactionType.expense,
        )
    )
    transactions = result.scalars().all()
    if len(transactions) < 5:
        return []

    df = pd.DataFrame([{
        "id": t.id,
        "amount": t.amount,
        "description": t.description,
        "date": t.date,
        "category": t.category.name if t.category else "Uncategorized",
    } for t in transactions])

    anomalies = []
    for cat, group in df.groupby("category"):
        if len(group) < 3:
            continue
        mean, std = group["amount"].mean(), group["amount"].std()
        flagged = group[group["amount"] > mean + 2 * std]
        for _, row in flagged.iterrows():
            anomalies.append({
                "transaction_id": int(row["id"]),
                "description": row["description"],
                "amount": float(row["amount"]),
                "category": cat,
                "date": row["date"].isoformat(),
                "avg_for_category": round(float(mean), 2),
                "message": f"This ₹{row['amount']:,.0f} {cat} expense is unusually high (avg ₹{mean:,.0f})",
            })

    return sorted(anomalies, key=lambda x: x["amount"], reverse=True)[:5]
